/**
 * Created by Admin on 2017-05-10.
 */
const http = require('http');
const socketio = require('socket.io');
const fs = require('fs');
const express = require('express');
const app = express();

app.use(express.static(__dirname + '/public'));

var roomName = 'client';
var sockets = {}; //이름과 id를 보관
sockets.connected = [];


/*
// http 서버를 생성합니다.
const server = http.createServer(function(request, response) {
    fs.readFile("client.html", function(error, data) {
        response.writeHead(200, {"Content-Type": "text/html"});
        response.end(data);
    });

}).listen(3000, function() {
     console.log("Server running at http://localhost:3000");
});
*/

//httpServer를 express서버로 생성
const server = http.createServer(app);
server.listen(3000,function(){
    console.log('Server running at http://localhost:3000');
});

//listen : 서버가 이때 만들어지는데 소켓은 http서버가 필요함
const io = socketio.listen(server);

//socket 방금연결된 브라우져
io.sockets.on('connection',function(socket){
//////
    socket.on('join', function(data) {
        sockets.connected.push({'name': data, 'id': socket.id});
        socket.emit('view_member', sockets.connected);
        //현재 접속해 있는 사람들에게 새사람이 들어옴을 알림
        io.sockets.in(roomName).emit('replace_member', {'name': data, 'id': socket.id});
        socket.name = data;
        socket.join(roomName);
    });
    //귓속말
    socket.on("sendTo", function(data) {
    //전체 방에있는 사람들중. 특정소켓에게 emit함 (data.to) : 소켓의 id 
    io.sockets.in(roomName).sockets[data.to].emit('receive', data.message);
    });
//////

    //접속한 브라우져객체를 방에 넣는다 접속한 브라우저 객체를 대화 풀에 접속시킨다
    //chat 이라는 방에 넣음
    socket.join("chat");
    socket.emit("getMyId",socket.id);
    console.log(' 브라우저가 연결되었습니다. ' + socket.id);

    //on: 이벤트를 등록함 data 호출시 전달된 parameger
    socket.on("broadcast", function(data) {
        console.log("Client send data : " + data);
        // emit: on으로 등록되어 있는 이벤트를 호출하여 data를 전달
        //1. 하나의 클라이언트에만 (접속되어 있는 나에게만) 등록된 receive 이벤트를 수행합니다.
        //socket.emit('receive', data);
        // 2. 방에 있는 모든 브라우져에게 receive 이벤트를 수행시킴
        io.sockets.in("chat").emit('receive',data);
    });
});

app.use(function(req,res){
    fs.readFile('client.html','utf-8',function(err,data){
       res.type('text/html');
       res.send(data);
    });
});