/**
 * Created by Admin on 2017-05-08.
 */
const ejs = require('ejs');
const express = require('express');
const fs = require('fs');
const bodyParser = require('body-parser');
const path = require('path');
const app = express();

app.use(express.static(__dirname+'/static'));

app.use('/node_modules',express.static(path.join(__dirname,'node_modules')));

app.use(bodyParser.urlencoded({extended: false}));


let teamIndex = 0;
let playerIndex = 0;


const players=[
    {teamName:'hanhwa',playerName: 'ehm', id: playerIndex++}
];
const teams=[
    {teamName: 'hanhwa',player: players[teamIndex],id: teamIndex++}
];
//list
app.get('/',function(req,res){
    fs.readFile('main.ejs','utf8',function(err,data){
        res.writeHead(200,{'Content-Type' : 'text/html'});
        res.end(ejs.render(data,{
            teams :teams
        }))
    });
});

//teamAdd
app.post('/addTeam',function(req,res){
    fs.readFile('main.ejs','utf8',function(err,data){
        const team = {};
        let memberName = req.body.memberName;

        team.teamName = teamName;
        team.id = teamIndex++;

        teams.push(team);
        console.log(teams);

        res.redirect('/');
    });
});

//memberAdd
app.post('/addMember',function(req,res){
    fs.readFile('main.ejs','utf8',function(err,data){

        const plyer = {};
        let teamName = req.body.teamName;
        let playerName = req.body.playerName;

        plyer.teamName = teamName;
        plyer.playerName = playerName;
        plyer.id = playerIndex++;

        players.push(plyer);
        console.log(players);
        //////////////////////
        team.teamName = teamName;
        team.id = teamIndex++;
        team.player = plyer;

        teams.push(team);
        console.log(teams);
        //////////////////////
        res.redirect('/');
    });
});

//detail
app.get('/team/:id',function(req,res){
    let id = req.params.id;
    let teamName = teams[id].teamName;

    let playerId  = 0;
    if ( players.teamName == teamName) {
        playerId = players.id;
        console.log('playerId' + playerId);
    }

    fs.readFile('main.ejs','utf8', function(err, data) {
        res.writeHead(200, {'Content-Type': 'text/html'});
        res.end(ejs.render(data,{
            teams : teams,
            team : teams[id],
            players : players[playerId]
        }));
    });
});


app.use(function(req,res){
    res.type('text/html');
    res.sendStatus(404);
});

app.use(function(req,res){
    res.type('text/html');
    res.sendStatus(500);
});


app.listen(3000,function(){
    console.log('Server start Baseball');
});